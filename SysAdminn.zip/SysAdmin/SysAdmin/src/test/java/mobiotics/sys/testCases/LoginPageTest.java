package mobiotics.sys.testCases;

import org.testng.annotations.Test;

import mobiotics.sys.constant.BaseTest;

public class LoginPageTest extends BaseTest {

		
		@Test
		public void Login() throws Exception  {
			preCondition();

}
}
